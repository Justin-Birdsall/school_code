Recourses:

GVSU Style Guide link to start practicing: