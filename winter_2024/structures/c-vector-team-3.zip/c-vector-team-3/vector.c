/**
 * Generic vector library
 *
 * Proof of concept; not meant to be very robust.
 * Just make sure we have no memory leaks and that it works.
 * 
 * The vector will hold a dynamically sized memory area (basically an
 * array) of **addresses**.  Remember that all addresses are the same size.
 *
 * Create a new vector with the macros given in the .h file:
 * vector* nums = VECTOR_NEW(int, 100)	-> New vector of ints, initial size 100.
 * vector* char = VECTOR_NEW(char, 10)  -> New vector of char, initial size 10.
 * etc.
 *
 * Add to a vector by passing the address of the element you wish to add:
 * int x = 42;
 * vec_add(nums, &x);
 *
 * Get an element from the vector with the provided macro:
 * int y = VECTOR_GET(nums, 0)  -> Get element #0 from the vector.
 *
 * January 2024
 * Ira Woodring
 **/

#include "vector.h"
#include <stdbool.h>
#include <string.h>

static bool vec_grow(vector* vec);
static bool vec_shrink(vector* vec);

// Data structure for a vector.  Length is how many pieces
// of data are currently held.  Capacity is the total we can
// hold.  type_size is the number of bytes per pieces of data.
//typedef struct vector_t {
//    size_t length;
//    size_t capacity;
//    size_t type_size;
//    float filled_percentage;
//    void** data;
//} vector;


/**
 * Make a new vector.  This function acts like a constructor
 * (or it would if C had objects).  Set default state
 * of the struct after you make memory for it,
 * and return the created vector.  Default state is length
 * of zero, capacity of initial_size, type_size of type_size
 * and filled percentage 0.
 */

// So this would hold our struct correct? Or where are we making the struct? Is type_size the size in bits of what
// we are storing?
// Or is type_size the type of what we are storing and then we get the sizeof(type_size) to get the number of bits
// it is
// Do we not have to define a main() function?

// From in class Tuesday: Can you explain how the main function takes parameters? It's main so nothing has been done yet so how would it take
// parameters?
vector* new_vec(size_t type_size, size_t initial_size){
    vector * vecPtr = malloc(sizeof(vector));
    //^^^^^^^^^^^^^^^^^ look at slide 58 from the oh I C on blackboard
    if (vecPtr == NULL) {
        //see header vector header file for more information on stderr and fprintf
        printf( "Memory allocation failed\n");
        //since we don't have anything exit
    }
    // When we create an array, since default length is 0, does that mean we create it with array[0] or can we do array[some_interger] like
    // array[10] and the length is still 0 since we haven't added anything to this array?
    vecPtr -> length = 0;
    //since we know the initial size of the vector I believe we can just set it to this
    vecPtr -> capacity = initial_size;
    vecPtr -> type_size = type_size;
    vecPtr -> filled_percentage = 0.0f;
    // Create a vector pointer data and create enough data on the heap for the vector and the initial
    vecPtr->data = malloc(sizeof(void*) * initial_size);
    //do same for data. if they make a vector 10 big but no data these is no sense in storing anything
    if (vecPtr->data == NULL) {
        //see header vector header file for more information on stderr and fprintf
        printf( "memory allocation failed\n");
        //since we don't have anything exit
    }
   return vecPtr;
}

/**
 * Add an item to the vector.
 * We are given an address for the element.  We need to:
 * - see if we have space in our address table for another element
    * - grow if we don't
 * - create new area in memory of the size of the element we are given
 * - use memcpy to copy the memory from the address of the element to the new area
 * - store the pointer given back in the vector at the current length
 * - increase length
 */

void vec_add(vector* vec, void* element){
    // If the length of the vector is equal to the capacity then our vector is full
    if (vec->length == vec->capacity){
        // Since our vector is full we need to call the vec grow function on the address of the pointer
        // to our vector.
        vec_grow(vec);
    }
    // Make space on heap that is the size of the element.
    // Should we be making space using the sizeof(element) or sizeof(vec->type_size). WOuld be the same correct?
    // is element now on the heap? Or is it still on the stack now?
    void* newData = malloc(vec->type_size);
    //Now we made a ptr to the newData, let's store the data of element in there on the heap.
    memcpy(newData, element, vec->type_size);
    // Our length = to index new element should go in the array since it's the number of elements we have
    // currently stored in our array. So we could just use this index to put our data at this spot.
    vec->data[vec->length] = newData;
    vec->length++;
}

/**
 * Get an item from the vector, at the given index (it is exists).
 * No tricks here; just make sure index is in correct bounds,
 * then return the address of the element if it is.
 * Return NULL otherwise.
 */

void* vec_get(vector* vec, size_t index){
    // use the vectors length since if we use capacity, the array may not actually be using the entire capacity.
    // Perhaps only one element is currently being stored.
    // Length - 1 because length for one element = 1, but the index value would be 0.
    if(index > (vec->length) - 1){
        printf("you indexed out of the vectors capacity\n");
    }
    // It's a valid index so return the data at that spot. Return the data or the address?
    else{
        return (vec->data[index]);
    }
}

/**
 * Remove an item from the vector, and mark its memory
 * area NULL.
 *
 * Extra credit: If we go below 25% usage, resize the vector
 * to half its current size by calling vec_shrink.
 */

void* vec_remove(vector* vec, size_t index){
    //need to access the vector data C from the pointer
    //get the index that we passed in then delete 
    //that element and shift everything down one (for loop)
    
// make sure the index is in range of our array
    if (index > (vec ->length) - 1) {
        printf("Invalid Index");
    }
    // If it's a valid index we want to remove that element
    else {
        // the element exists on the heap and we do not want any memory leaks. So we should set a variable
        // To the element that is going to be freed.
        void* element_to_free = vec->data[index];
        // Before we free this element, we have to change the data at the array position to NULL. Otherwise free returns
        // void, and void would be stored here. Technically don't have to do it in this order though. Just helps me
        // To think about it.
        vec->data[index] = NULL;
        // We now have access to the element we want to remove; let's use this variable and free it
        // So that it's no longer on the heap and we don't have any memory leaks.
        free(element_to_free);
//        vec->length = vec->length - 1;
        // Element should've been successfully removed
    }
}

/**
 * Cleanup our memory when the user is done with the vector.
 * Keep in mind we allocated memory for the vector itself,
 * the dynamic array called data, and each of its elements.
 */
//vec_clean up should just loop though and free all of the inputs of the array. and then free the vector
//can run valgrind to see if there are any leaks present to ensure that we clean up correctly 
void vec_cleanup(vector* vec){
	// Remember; length is the current location
	// to store an element, so don't go past it.
    for (size_t i = 0; i < vec -> length; i++) {
        free(vec->data[i]);
    }
    //now that all of the elements of the data are free
    //we should be able to free the rest of the vector pointers
    //NOTE: make sure not to free the actual vector before freeing the pointers

    // I'm pretty sure we don't need to free the individual components, and can just free(vec).
    free(vec->data);
    //since we freed everything we can free the vec itself
    free(vec);   
}

/**
 * Shrink the vector if it is largely empty.
 * Used if we remove a lot of items, to free up memory.
 * If we go below 25% usage reshrink the vector to half it's size.
 * Extra Credit.
 **/

static bool vec_shrink(vector* vec){
	return NULL;
}

/**
 * Grow the vector if we run out of room.
 *
 * NOTE: Do not use realloc; I want to see that you understand how
 * to do it on your own.
 *
 * Note: "static" in this context makes this function invisible outside
 * of this file.
 */

static bool vec_grow(vector* vec){
    //i have in my notes from prof rahit that standard resize is *2 + 1
    size_t grow_amount = (vec -> capacity * 2) + 1;
    //create a new vector point pointer. (void star so we don't have to care about type)
    void** new_array = malloc(sizeof(void*) *  grow_amount);
    //test to make sure we allocated properly
    if(new_array == NULL) {
        //copy and paste an the error message.
        printf("No more space on heap");
        return false;
    }
    //copy the elements of our full vector to the now resized one
    for(size_t i = 0; i < vec->length;i++){
        if (vec -> data[i] != NULL)
        {
            new_array[i] = vec->data[i];
        }
    }
    //since we transferred everything over we can just free the pointer to that data
    free(vec->data);
    //now we need to make our original vector point to the new data memory and update the capacity
    vec->data = new_array;
    vec->capacity = grow_amount;
    return true;
    }


void print_vector(const vector* vec) {
    size_t i;
    for (i = 0; i < vec->length; ++i) {
        // Assuming int elements in the vector
        int* current_element = (int*)(vec->data[i]);
        if (current_element != NULL) {
            printf("%d\n", *current_element);
        }
    }
    printf("done\n");
}


int main(){
    size_t byte_size = sizeof(int);
    // Successful creation of a vector storing ints
    vector* vectorPtr = new_vec(byte_size, 1);
    int varToAdd = 6;
    vec_add(vectorPtr, &varToAdd);
    varToAdd = 10;
    vec_add(vectorPtr, &varToAdd);
    print_vector(vectorPtr);
    // vec_add for integers seems to work and add elements. Time to test vec_grow.
    // vec grow works
    // Now time to test vec_get.
    int* dataAtIndex = vec_get( vectorPtr, 1);
    printf("data at index 1: %d\n", *dataAtIndex);
    // Vec_get works. Now test vec_remove
    varToAdd = 24;
    vec_add(vectorPtr, &varToAdd);
    varToAdd = 22;
    vec_add(vectorPtr, &varToAdd);
    print_vector(vectorPtr);
    vec_remove(vectorPtr, 2);
    print_vector(vectorPtr);
    // vec_remove seems to work, now to test vec_cleanup.
    vec_cleanup(vectorPtr);
    // vec cleanup seems to work
    printf("\n");

}
