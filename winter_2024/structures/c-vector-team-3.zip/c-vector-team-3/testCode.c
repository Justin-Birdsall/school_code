////
//// Created by Alec Mirambeau on 1/27/24.
////
//#include "vector.c"
//
//void print_vector(const vector* vec) {
//    size_t i;
//    for (i = 0; i < vec->length; ++i) {
//        // Assuming int elements in the vector
//        int* current_element = (int*)(vec->data[i]);
//        if (current_element != NULL) {
//            printf("%d\n", *current_element);
//        }
//    }
//    printf("done\n");
//}
//
//
//int main(){
//    size_t byte_size = sizeof(int);
//    // Successful creation of a vector storing ints
//    vector* vectorPtr = new_vec(byte_size, 1);
//    int varToAdd = 6;
//    vec_add(vectorPtr, &varToAdd);
//    varToAdd = 10;
//    vec_add(vectorPtr, &varToAdd);
//    print_vector(vectorPtr);
//    // vec_add for integers seems to work and add elements. Time to test vec_grow.
//    // vec grow works
//    // Now time to test vec_get.
//    int* dataAtIndex = vec_get( vectorPtr, 1);
//    printf("data at index 1: %d\n", *dataAtIndex);
//    // Vec_get works. Now test vec_remove
//    varToAdd = 24;
//    vec_add(vectorPtr, &varToAdd);
//    varToAdd = 22;
//    vec_add(vectorPtr, &varToAdd);
//    print_vector(vectorPtr);
//    vec_remove(vectorPtr, 2);
//    print_vector(vectorPtr);
//    // vec_remove seems to work, now to test vec_cleanup.
//    vec_cleanup(vectorPtr);
//    // vec cleanup seems to work
//    printf("\n");
//
//}
